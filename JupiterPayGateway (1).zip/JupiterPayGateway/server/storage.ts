import { transactions, type Transaction, type InsertTransaction } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  createTransaction(tx: InsertTransaction): Promise<Transaction>;
  getTransactionsByMerchant(address: string): Promise<Transaction[]>;
  updateTransactionStatus(id: number, status: string, txHash?: string, swapTxHash?: string): Promise<Transaction>;
}

export class DatabaseStorage implements IStorage {
  async createTransaction(tx: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db
      .insert(transactions)
      .values(tx)
      .returning();
    return transaction;
  }

  async getTransactionsByMerchant(address: string): Promise<Transaction[]> {
    return db
      .select()
      .from(transactions)
      .where(eq(transactions.merchantAddress, address))
      .orderBy(transactions.createdAt);
  }

  async updateTransactionStatus(
    id: number,
    status: string,
    txHash?: string,
    swapTxHash?: string
  ): Promise<Transaction> {
    const [transaction] = await db
      .update(transactions)
      .set({ status, txHash, swapTxHash })
      .where(eq(transactions.id, id))
      .returning();

    if (!transaction) {
      throw new Error("Transaction not found");
    }

    return transaction;
  }
}

export const storage = new DatabaseStorage();