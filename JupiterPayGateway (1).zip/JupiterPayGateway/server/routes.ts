import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertTransactionSchema } from "@shared/schema";

export async function registerRoutes(app: Express) {
  app.post("/api/transactions", async (req, res) => {
    try {
      const data = insertTransactionSchema.parse(req.body);
      const tx = await storage.createTransaction(data);
      res.json(tx);
    } catch (err) {
      res.status(400).json({ message: "Invalid transaction data" });
    }
  });

  app.get("/api/transactions/:address", async (req, res) => {
    const { address } = req.params;
    const transactions = await storage.getTransactionsByMerchant(address);
    res.json(transactions);
  });

  app.patch("/api/transactions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { status, txHash, swapTxHash } = req.body;
      const tx = await storage.updateTransactionStatus(
        parseInt(id),
        status,
        txHash,
        swapTxHash
      );
      res.json(tx);
    } catch (err) {
      res.status(400).json({ message: "Failed to update transaction" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
