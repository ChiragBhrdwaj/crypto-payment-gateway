# Crypto Payment Gateway with Jupiter Integration

This project implements a crypto payment gateway that uses Jupiter for token swaps and USDC settlement on Solana.

## Local Development Setup

1. **Clone and Install Dependencies:**
```bash
# Install dependencies
npm install

# Install Solana-specific packages
npm install @solana/web3.js@1.87.6
npm install @solana/wallet-adapter-react@0.15.35
npm install @solana/wallet-adapter-base@0.9.23
npm install @solana/wallet-adapter-wallets@0.19.24
npm install @solana/wallet-adapter-react-ui@0.9.34
npm install @jup-ag/core@4.0.0-beta.22
```

2. **Database Setup:**
```bash
# Create a PostgreSQL database
createdb crypto_gateway

# Set up your environment variables in .env:
DATABASE_URL=postgresql://username:password@localhost:5432/crypto_gateway
PGUSER=your_username
PGPASSWORD=your_password
PGDATABASE=crypto_gateway
PGHOST=localhost
PGPORT=5432

# Initialize the database schema
npm run db:push
```

3. **Start Development Server:**
```bash
npm run dev
```

The application will be available at `http://localhost:5000`.

## Features

- Connect Phantom Wallet
- Process payments in SOL, USDC, and BONK tokens
- Automatic token swaps via Jupiter
- Transaction history for merchants
- USDC settlement

## API Endpoints

### Create Transaction
- **POST** `/api/transactions`
```json
{
  "merchantAddress": "string",
  "amount": "string",
  "inputToken": "string",
  "status": "pending"
}
```

### Get Merchant Transactions
- **GET** `/api/transactions/:address`

### Update Transaction
- **PATCH** `/api/transactions/:id`
```json
{
  "status": "string",
  "txHash": "string",
  "swapTxHash": "string"
}
```

## Deploying to Vercel

1. **Install Vercel CLI:**
```bash
npm install -g vercel
```

2. **Login to Vercel:**
```bash
vercel login
```

3. **Deploy the Project:**
```bash
# Initial deployment
vercel

# For subsequent deployments
vercel --prod
```

4. **Environment Variables:**
Set up the following environment variables in your Vercel project settings:
- `DATABASE_URL`
- `PGUSER`
- `PGPASSWORD`
- `PGDATABASE`
- `PGHOST`
- `PGPORT`

5. **Database Setup:**
- Create a PostgreSQL database (recommended: Neon, Supabase, or any Postgres provider)
- Update the environment variables in Vercel with your database credentials
- The schema will be automatically migrated during deployment

## Important Notes

- The application uses Solana devnet by default
- Keep test transactions small
- Never commit .env files or private keys
- Always verify transaction status in the UI

## Troubleshooting

### Database Connection Issues:
- Verify PostgreSQL is running: `pg_isready`
- Check DATABASE_URL format
- Ensure database exists: `psql -l`

### Wallet Connection Issues:
- Make sure Phantom extension is installed
- Switch Phantom to devnet network
- Clear browser cache if necessary

### Build Issues:
- Clear node_modules: `rm -rf node_modules`
- Clean npm cache: `npm cache clean --force`
- Reinstall dependencies: `npm install`