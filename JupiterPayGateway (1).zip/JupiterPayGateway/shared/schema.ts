import { pgTable, text, serial, timestamp, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  merchantAddress: text("merchant_address").notNull(),
  amount: numeric("amount").notNull(),
  inputToken: text("input_token").notNull(),
  status: text("status", { enum: ["pending", "completed", "failed"] }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  txHash: text("tx_hash"),
  swapTxHash: text("swap_tx_hash"),
});

export const insertTransactionSchema = createInsertSchema(transactions)
  .omit({
    id: true,
    createdAt: true,
    txHash: true,
    swapTxHash: true,
  })
  .refine(
    (data) => ["pending", "completed", "failed"].includes(data.status),
    {
      message: "Status must be either 'pending', 'completed', or 'failed'",
      path: ["status"],
    }
  );

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;