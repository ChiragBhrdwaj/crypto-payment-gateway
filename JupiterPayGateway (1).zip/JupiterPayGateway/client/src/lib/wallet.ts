import { PublicKey } from "@solana/web3.js";

declare global {
  interface Window {
    solana?: any;
  }
}

export interface WalletAdapter {
  connect(): Promise<void>;
  disconnect(): Promise<void>;
  publicKey: PublicKey | null;
  connected: boolean;
}

class PhantomWallet implements WalletAdapter {
  publicKey: PublicKey | null = null;
  connected: boolean = false;

  async connect(): Promise<void> {
    try {
      if (!window.solana) {
        throw new Error("Phantom wallet not found");
      }

      const resp = await window.solana.connect();
      this.publicKey = new PublicKey(resp.publicKey.toString());
      this.connected = true;
    } catch (err) {
      console.error("Failed to connect wallet:", err);
      throw err;
    }
  }

  async disconnect(): Promise<void> {
    try {
      if (!window.solana) return;
      await window.solana.disconnect();
      this.publicKey = null;
      this.connected = false;
    } catch (err) {
      console.error("Failed to disconnect wallet:", err);
    }
  }
}

const wallet = new PhantomWallet();

export function getWallet(): WalletAdapter {
  return wallet;
}

export async function connectWallet(): Promise<void> {
  await getWallet().connect();
}

export async function disconnectWallet(): Promise<void> {
  await getWallet().disconnect();
}