import { Transaction } from "@shared/schema";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";

interface TransactionHistoryProps {
  transactions?: Transaction[];
  isLoading: boolean;
}

export function TransactionHistory({ transactions, isLoading }: TransactionHistoryProps) {
  if (isLoading) {
    return <Skeleton className="w-full h-[200px]" />;
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Date</TableHead>
          <TableHead>Amount</TableHead>
          <TableHead>Token</TableHead>
          <TableHead>Status</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {transactions?.map((tx) => (
          <TableRow key={tx.id}>
            <TableCell>
              {new Date(tx.createdAt).toLocaleDateString()}
            </TableCell>
            <TableCell>{tx.amount}</TableCell>
            <TableCell>{tx.inputToken}</TableCell>
            <TableCell>{tx.status}</TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
