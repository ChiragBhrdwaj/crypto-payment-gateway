import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Form, FormField, FormItem, FormLabel, FormControl } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { TokenSelect } from "@/components/TokenSelect";
import { insertTransactionSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { getWallet } from "@/lib/wallet";
import type { InsertTransaction } from "@shared/schema";

export function PaymentFlow() {
  const [isProcessing, setIsProcessing] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const { toast } = useToast();
  const wallet = getWallet();

  useEffect(() => {
    // Check if wallet is already connected
    setIsConnected(wallet.connected);
  }, []);

  const form = useForm<InsertTransaction>({
    resolver: zodResolver(insertTransactionSchema),
    defaultValues: {
      amount: "",
      inputToken: "",
      merchantAddress: "",
      status: "pending"
    }
  });

  async function handleConnect() {
    try {
      await wallet.connect();
      setIsConnected(true);
      form.setValue("merchantAddress", wallet.publicKey?.toBase58() || "");
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to connect wallet"
      });
    }
  }

  async function onSubmit(data: InsertTransaction) {
    try {
      setIsProcessing(true);
      if (!isConnected || !wallet.publicKey) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Please connect your wallet first"
        });
        return;
      }

      const tx = await apiRequest("POST", "/api/transactions", {
        ...data,
        merchantAddress: wallet.publicKey.toBase58()
      });

      toast({
        title: "Success",
        description: "Payment initiated successfully"
      });

      // Reset form after successful submission
      form.reset();

    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to process payment"
      });
    } finally {
      setIsProcessing(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <Button
          variant={isConnected ? "outline" : "default"}
          onClick={isConnected ? () => wallet.disconnect() : handleConnect}
        >
          {isConnected ? "Disconnect Wallet" : "Connect Phantom"}
        </Button>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="amount"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Amount</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="Enter amount" {...field} />
                </FormControl>
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="inputToken"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Token</FormLabel>
                <FormControl>
                  <TokenSelect value={field.value} onChange={field.onChange} />
                </FormControl>
              </FormItem>
            )}
          />

          <Button 
            type="submit" 
            className="w-full"
            disabled={isProcessing || !isConnected}
          >
            {isProcessing ? "Processing..." : isConnected ? "Pay Now" : "Connect Wallet to Pay"}
          </Button>
        </form>
      </Form>
    </div>
  );
}