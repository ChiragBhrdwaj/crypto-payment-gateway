import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const TOKENS = [
  { symbol: "SOL", name: "Solana" },
  { symbol: "USDC", name: "USD Coin" },
  { symbol: "BONK", name: "Bonk" },
];

interface TokenSelectProps {
  value: string;
  onChange: (value: string) => void;
}

export function TokenSelect({ value, onChange }: TokenSelectProps) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger>
        <SelectValue placeholder="Select token" />
      </SelectTrigger>
      <SelectContent>
        {TOKENS.map((token) => (
          <SelectItem key={token.symbol} value={token.symbol}>
            {token.name} ({token.symbol})
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
