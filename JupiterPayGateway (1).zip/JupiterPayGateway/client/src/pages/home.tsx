import { PaymentFlow } from "@/components/PaymentFlow";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary/20 flex items-center justify-center p-4">
      <Card className="w-full max-w-lg">
        <CardHeader>
          <CardTitle className="text-center">
            <span className="bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Crypto Payment Gateway
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <PaymentFlow />
        </CardContent>
      </Card>
    </div>
  );
}
