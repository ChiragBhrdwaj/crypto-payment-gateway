import { TransactionHistory } from "@/components/TransactionHistory";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { getWallet } from "@/lib/wallet";
import type { Transaction } from "@shared/schema";

export default function Dashboard() {
  const wallet = getWallet();
  const { data: transactions, isLoading } = useQuery<Transaction[]>({
    queryKey: [`/api/transactions/${wallet?.publicKey?.toBase58()}`],
    enabled: !!wallet?.publicKey,
  });

  if (!wallet?.connected) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Card>
          <CardContent className="p-6">
            Please connect your wallet to view the dashboard
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4">
      <Card>
        <CardHeader>
          <CardTitle>Merchant Dashboard</CardTitle>
        </CardHeader>
        <CardContent>
          <TransactionHistory 
            transactions={transactions} 
            isLoading={isLoading} 
          />
        </CardContent>
      </Card>
    </div>
  );
}